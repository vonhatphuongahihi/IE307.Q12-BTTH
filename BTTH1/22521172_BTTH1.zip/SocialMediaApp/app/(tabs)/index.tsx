// 22521172 - Võ Nhất Phương
import React from 'react';
import PostList from '../../components/PostList';

export default function HomeScreen() {
  return <PostList />;
}


