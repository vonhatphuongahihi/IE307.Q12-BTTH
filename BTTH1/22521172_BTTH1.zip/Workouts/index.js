// 22521172 - Võ Nhất Phương
import { registerRootComponent } from 'expo';
import App from './App';

registerRootComponent(App);